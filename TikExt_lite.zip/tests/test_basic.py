import tikext

def test_hello():
    assert tikext.hello("Mustafa") == "Hello, Mustafa!"
