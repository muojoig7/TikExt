__all__ = ["hello"]

def hello(name="world"):
    return f"Hello, {name}!"
